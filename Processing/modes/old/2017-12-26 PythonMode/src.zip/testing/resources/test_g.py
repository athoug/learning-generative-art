import processing.opengl.PGraphics3D

def setup():
    size(100, 100, P3D)

def draw():
    assert(isinstance(g, processing.opengl.PGraphics3D))
    print 'OK'
    exit()
