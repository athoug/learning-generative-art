# should throw a syntax error

print True && False
print 'OK'
exit()